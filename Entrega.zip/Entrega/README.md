# Tarea_INFO145
Todos los algoritmos de piden las entradas desde consola de ser necesario, por lo que no hay restriccion para la ejecucion.
El archivo make en Escaleras compila todas las versiones, como su funcionamiento interno es distinto, deben iniciarse por separado desde la consola.

Solo el algoritmo greedy y el escalera 64 de fuerza bruta piden los parametros para iniciar.

Se incluyo un graficador en python para el algoritmo greedy, para usarlo, hay que tener instalada la libreria networkx, y para cargar el grafico solo hay que copiar las transiciones que entrega solGreedyAleatorio en el arreglo de transiciones en el codigo, luego al ejecutarlo, opcionalmente se puede indicar el nodo inicial y final, para que sean resaltados con otro color, ademas, el graficador indicara si en el digrafo hay una transicion de ida y vuelta, ya que el numero de una de ellas sobreescribe el de la otra al generar la imagen.

Los algoritmos adicionales incluidos en Escaleras/variantes y otros codigos/ no estan pensados en ser vueltos a ejecutar, y fueron descartados o solo usados para hacer ciertos graficos.